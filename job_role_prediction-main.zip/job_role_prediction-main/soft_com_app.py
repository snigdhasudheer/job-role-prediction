import streamlit as st
from soft_predict import show_predict_page
# from soft_explore_page import show_explore_page
# page=st.sidebar.selectbox("Predict Or Explore",["Predict","Explore"])
show_predict_page()
# if(page=="Predict"):
    
# elif(page=="Explore"):
#     show_explore_page()
